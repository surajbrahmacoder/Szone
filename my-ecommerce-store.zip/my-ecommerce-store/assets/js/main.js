document.addEventListener('DOMContentLoaded', () => {

    // =================================================================
    // 1. DATA: Product list with sizes added
    // =================================================================
    const products = [
      // Shirts (T-Shirts & Polos)
      { id: 1, name: 'Classic Crew Neck Tee', price: 999, category: 'Shirts', image: 'https://placehold.co/400x400/fca5a5/333?text=Crew+Tee', description: 'A timeless staple, made from 100% premium soft cotton.', sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'] },
      { id: 2, name: 'Performance Polo Shirt', price: 1999, category: 'Shirts', image: 'https://placehold.co/400x400/6ee7b7/333?text=Polo+Shirt', description: 'Moisture-wicking fabric to keep you cool and comfortable.', sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'] },
      { id: 3, name: 'Graphic Print T-Shirt', price: 1299, category: 'Shirts', image: 'https://placehold.co/400x400/c4b5fd/333?text=Graphic+Tee', description: 'Express yourself with our unique, artistic graphic prints.', sizes: ['XS', 'S', 'M', 'L', 'XL'] },
      { id: 4, name: 'V-Neck T-Shirt', price: 999, category: 'Shirts', image: 'https://placehold.co/400x400/fdba74/333?text=V-Neck+Tee', description: 'A flattering V-neck cut in a variety of essential colors.', sizes: ['S', 'M', 'L', 'XL'] },
      { id: 5, name: 'Long Sleeve Henley', price: 1799, category: 'Shirts', image: 'https://placehold.co/400x400/818cf8/333?text=Henley', description: 'A casual long sleeve shirt with a classic buttoned placket.', sizes: ['S', 'M', 'L', 'XL', 'XXL'] },
      { id: 6, name: 'Striped Polo Shirt', price: 2199, category: 'Shirts', image: 'https://placehold.co/400x400/facc15/333?text=Striped+Polo', description: 'A preppy classic with bold, modern stripes.', sizes: ['S', 'M', 'L', 'XL'] },
      { id: 28, name: 'Oxford Button-Down Shirt', price: 2599, category: 'Shirts', image: 'https://placehold.co/400x400/7dd3fc/333?text=Oxford+Shirt', description: 'A versatile wardrobe essential for a crisp, smart look.', sizes: ['S', 'M', 'L', 'XL', 'XXL'] },
      { id: 29, name: 'Flannel Plaid Shirt', price: 2899, category: 'Shirts', image: 'https://placehold.co/400x400/fca5a5/333?text=Flannel', description: 'Soft, warm, and perfect for a rugged, layered style.', sizes: ['M', 'L', 'XL', 'XXL'] },
      { id: 30, name: 'Linen Short Sleeve Shirt', price: 2399, category: 'Shirts', image: 'https://placehold.co/400x400/fdba74/333?text=Linen+Shirt', description: 'Stay cool and stylish in this breathable linen shirt.', sizes: ['S', 'M', 'L'] },

      // Bottoms (Jeans & Trousers)
      { id: 7, name: 'Slim Fit Denim Jeans', price: 2999, category: 'Bottoms', image: 'https://placehold.co/400x400/a7f3d0/333?text=Denim+Jeans', description: 'Modern slim fit jeans that combine style with flexibility.', sizes: ['28', '30', '32', '34', '36'] },
      { id: 8, name: 'Comfort-Stretch Chinos', price: 2499, category: 'Bottoms', image: 'https://placehold.co/400x400/f9a8d4/333?text=Chinos', description: 'Versatile chino pants with added stretch for all-day comfort.', sizes: ['28', '30', '32', '34', '36'] },
      { id: 9, name: 'Relaxed Fit Cargo Trousers', price: 3499, category: 'Bottoms', image: 'https://placehold.co/400x400/a5b4fc/333?text=Cargo+Pants', description: 'Functional and fashionable with ample pocket space.', sizes: ['30', '32', '34', '36', '38'] },
      { id: 10, name: 'Tailored Formal Trousers', price: 3999, category: 'Bottoms', image: 'https://placehold.co/400x400/99f6e4/333?text=Trousers', description: 'Sharply tailored trousers for a polished, professional look.', sizes: ['30', '32', '34', '36'] },
      { id: 11, name: 'Jogger Sweatpants', price: 2299, category: 'Bottoms', image: 'https://placehold.co/400x400/d8b4fe/333?text=Joggers', description: 'The ultimate in comfort for lounging or casual outings.', sizes: ['S', 'M', 'L', 'XL'] },
      { id: 12, name: 'Linen Drawstring Trousers', price: 2799, category: 'Bottoms', image: 'https://placehold.co/400x400/fbcfe8/333?text=Linen+Pants', description: 'Lightweight and breathable, perfect for warm weather.', sizes: ['S', 'M', 'L'] },
      { id: 31, name: 'Twill Jogger Pants', price: 2699, category: 'Bottoms', image: 'https://placehold.co/400x400/6ee7b7/333?text=Twill+Joggers', description: 'A smart-casual hybrid of joggers and chinos.', sizes: ['S', 'M', 'L', 'XL'] },
      { id: 32, name: 'Wool Blend Trousers', price: 4299, category: 'Bottoms', image: 'https://placehold.co/400x400/c4b5fd/333?text=Wool+Trousers', description: 'Warm and sophisticated trousers for the colder seasons.', sizes: ['30', '32', '34', '36'] },
      { id: 33, name: 'Denim Shorts', price: 1999, category: 'Bottoms', image: 'https://placehold.co/400x400/818cf8/333?text=Denim+Shorts', description: 'A summer staple for a timeless, casual look.', sizes: ['28', '30', '32', '34'] },

      // Outerwear (Jackets)
      { id: 13, name: 'Urban Explorer Jacket', price: 4999, category: 'Outerwear', image: 'https://placehold.co/400x400/93c5fd/333?text=Urban+Jacket', description: 'A stylish and durable jacket for all your city adventures.', sizes: ['S', 'M', 'L', 'XL'] },
      { id: 14, name: 'Classic Denim Jacket', price: 3999, category: 'Outerwear', image: 'https://placehold.co/400x400/6b7280/333?text=Denim+Jacket', description: 'An iconic and versatile layering piece for any season.', sizes: ['S', 'M', 'L', 'XL'] },
      { id: 15, name: 'Lightweight Bomber Jacket', price: 4499, category: 'Outerwear', image: 'https://placehold.co/400x400/ef4444/333?text=Bomber', description: 'A modern, sleek bomber jacket perfect for transitional weather.', sizes: ['S', 'M', 'L', 'XL'] },
      { id: 16, name: 'Signature Graphic Hoodie', price: 3299, category: 'Outerwear', image: 'https://placehold.co/400x400/22c55e/333?text=Hoodie', description: 'Stay warm with our signature Szone logo fleece-lined hoodie.', sizes: ['S', 'M', 'L', 'XL', 'XXL'] },
      { id: 17, name: 'Quilted Puffer Vest', price: 3799, category: 'Outerwear', image: 'https://placehold.co/400x400/ec4899/333?text=Vest', description: 'A stylish and warm vest for core insulation without bulky sleeves.', sizes: ['S', 'M', 'L'] },
      { id: 34, name: 'Technical Raincoat', price: 5999, category: 'Outerwear', image: 'https://placehold.co/400x400/facc15/333?text=Raincoat', description: 'Fully waterproof and windproof with a minimalist design.', sizes: ['S', 'M', 'L', 'XL'] },
      { id: 35, name: 'Merino Wool Cardigan', price: 4799, category: 'Outerwear', image: 'https://placehold.co/400x400/a7f3d0/333?text=Cardigan', description: 'A soft and versatile layering piece for all seasons.', sizes: ['S', 'M', 'L'] },
      { id: 36, name: 'Leather Biker Jacket', price: 8999, category: 'Outerwear', image: 'https://placehold.co/400x400/f9a8d4/333?text=Biker+Jacket', description: 'An iconic, edgy jacket made from premium quality leather.', sizes: ['S', 'M', 'L'] },

      // Footwear
      { id: 18, name: 'Leather Low-Top Sneakers', price: 4999, category: 'Footwear', image: 'https://placehold.co/400x400/fde047/333?text=Sneakers', description: 'Handcrafted from genuine leather for luxury and comfort.', sizes: ['6', '7', '8', '9', '10', '11'] },
      { id: 19, name: 'Suede Ankle Boots', price: 5499, category: 'Footwear', image: 'https://placehold.co/400x400/f87171/333?text=Ankle+Boots', description: 'Versatile and stylish boots with a comfortable block heel.', sizes: ['6', '7', '8', '9', '10'] },
      { id: 20, name: 'Canvas Slip-On Shoes', price: 2499, category: 'Footwear', image: 'https://placehold.co/400x400/fb923c/333?text=Slip-Ons', description: 'Effortless style and comfort for everyday wear.', sizes: ['7', '8', '9', '10', '11'] },
      { id: 21, name: 'Classic Leather Loafers', price: 4599, category: 'Footwear', image: 'https://placehold.co/400x400/a3e635/333?text=Loafers', description: 'Timeless elegance for a smart-casual or formal look.', sizes: ['7', '8', '9', '10'] },
      { id: 37, name: 'High-Top Canvas Sneakers', price: 3299, category: 'Footwear', image: 'https://placehold.co/400x400/99f6e4/333?text=High-Tops', description: 'A retro-inspired high-top for a cool, casual vibe.', sizes: ['6', '7', '8', '9', '10', '11'] },
      { id: 38, name: 'Leather Chelsea Boots', price: 6499, category: 'Footwear', image: 'https://placehold.co/400x400/d8b4fe/333?text=Chelsea+Boots', description: 'Sleek, stylish, and easy to wear with their elastic side panels.', sizes: ['7', '8', '9', '10', '11'] },
      { id: 39, name: 'Suede Desert Boots', price: 5599, category: 'Footwear', image: 'https://placehold.co/400x400/fbcfe8/333?text=Desert+Boots', description: 'A timeless silhouette that bridges the gap between smart and casual.', sizes: ['7', '8', '9', '10'] },

      // Accessories
      { id: 22, name: 'Minimalist Canvas Backpack', price: 2999, category: 'Accessories', image: 'https://placehold.co/400x400/d1d5db/333?text=Backpack', description: 'Sleek and modern with a padded laptop sleeve.', sizes: ['One Size'] },
      { id: 23, name: 'Classic Leather Belt', price: 1499, category: 'Accessories', image: 'https://placehold.co/400x400/a3a3a3/333?text=Belt', description: 'A timeless accessory made from genuine Italian leather.', sizes: ['S', 'M', 'L', 'XL'] },
      { id: 24, name: 'Aviator Sunglasses', price: 2299, category: 'Accessories', image: 'https://placehold.co/400x400/eab308/333?text=Sunglasses', description: 'Iconic style with a lightweight metal frame and full UV protection.', sizes: ['One Size'] },
      { id: 25, name: 'Fisherman Knit Beanie', price: 999, category: 'Accessories', image: 'https://placehold.co/400x400/64748b/333?text=Beanie', description: 'A cozy and stylish beanie made from soft, warm yarn.', sizes: ['One Size'] },
      { id: 26, name: 'Leather Tote Handbag', price: 5999, category: 'Accessories', image: 'https://placehold.co/400x400/f9a8d4/333?text=Handbag', description: 'A spacious and elegant leather tote for all your essentials.', sizes: ['One Size'] },
      { id: 27, name: 'Silk Patterned Scarf', price: 1899, category: 'Accessories', image: 'https://placehold.co/400x400/c084fc/333?text=Scarf', description: 'A touch of luxury to elevate any outfit.', sizes: ['One Size'] },
      { id: 40, name: 'Chronograph Watch', price: 9999, category: 'Accessories', image: 'https://placehold.co/400x400/6b7280/333?text=Watch', description: 'A sophisticated timepiece with a stainless steel case and leather strap.', sizes: ['S', 'M', 'L'] },
      { id: 41, name: 'Crossbody Bag', price: 2599, category: 'Accessories', image: 'https://placehold.co/400x400/ef4444/333?text=Crossbody+Bag', description: 'A compact and convenient bag for your on-the-go essentials.', sizes: ['One Size'] },
      { id: 42, name: 'Reversible Leather Belt', price: 1999, category: 'Accessories', image: 'https://placehold.co/400x400/22c55e/333?text=Reversible+Belt', description: 'Two colors in one. A versatile belt for a versatile wardrobe.', sizes: ['S', 'M', 'L', 'XL'] },
    ];

    // =================================================================
    // 2. CART & ORDER MANAGEMENT (updated to handle sizes)
    // =================================================================
    let cart = JSON.parse(localStorage.getItem('szone_shoppingCart')) || [];
    let orders = JSON.parse(localStorage.getItem('szone_orders')) || [];

    function saveCart() {
        localStorage.setItem('szone_shoppingCart', JSON.stringify(cart));
        updateCartCount();
    }

    function saveOrders() {
        localStorage.setItem('szone_orders', JSON.stringify(orders));
    }

    function addToCart(productId, size = 'One Size') {
        const existingProduct = cart.find(item => item.id === productId && item.size === size);
        if (existingProduct) {
            existingProduct.quantity++;
        } else {
            cart.push({ id: productId, quantity: 1, size });
        }
        saveCart();
    }
    
    function updateCartCount() {
        const cartCountElement = document.getElementById('cart-count');
        if (cartCountElement) {
            const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
            cartCountElement.textContent = totalItems;
        }
    }
    
    // Initial update on page load for all pages
    updateCartCount();

    // =================================================================
    // 3. PAGE-SPECIFIC LOGIC (updated with size selection)
    // =================================================================
    const path = window.location.pathname.split("/").pop();

    function renderProductGrid(productsToRender) {
      const productGrid = document.getElementById('product-grid');
      if (!productGrid) return;
      
      productGrid.innerHTML = ''; // Clear existing products
      if (productsToRender.length === 0) {
        productGrid.innerHTML = `<p class="text-center col-span-full text-gray-500">No products found in this category.</p>`;
        return;
      }

      productsToRender.forEach(product => {
          const card = document.createElement('div');
          card.className = 'bg-white rounded-lg shadow-md overflow-hidden product-card transition-all duration-300';
          card.innerHTML = `
                <a href="product.html?id=${product.id}">
                    <img src="${product.image}" alt="${product.name}" class="w-full h-64 object-cover">
                </a>
                <div class="p-6">
                    <h3 class="font-semibold text-lg mb-2">${product.name}</h3>
                    <p class="text-gray-700 text-xl font-bold mb-4">₹${product.price.toLocaleString('en-IN')}</p>
                    <button class="add-to-cart-btn w-full bg-indigo-600 text-white py-2 rounded-lg font-semibold hover:bg-indigo-700 transition duration-300" data-product-id="${product.id}">Add to Cart</button>
                </div>
          `;
          productGrid.appendChild(card);
      });

      // Re-attach event listeners to the new buttons
      productGrid.querySelectorAll('.add-to-cart-btn').forEach(button => {
          button.addEventListener('click', (e) => {
              const productId = parseInt(e.target.dataset.productId);
              addToCart(productId);
              e.target.innerText = 'Added!';
              e.target.classList.replace('bg-indigo-600', 'bg-green-500');
              setTimeout(() => {
                  e.target.innerText = 'Add to Cart';
                  e.target.classList.replace('bg-green-500', 'bg-indigo-600');
              }, 1500);
          });
      });
    }

    // --- Homepage Logic (`index.html`) ---
    if (path === 'index.html' || path === '') {
        // Show the first 8 products as "Featured"
        renderProductGrid(products.slice(0, 8));
    }

    // --- Shop Page Logic (`shop.html`) ---
    if (path === 'shop.html') {
        const filtersContainer = document.getElementById('category-filters');
        
        // Get unique categories from products
        const categories = ['All', ...new Set(products.map(p => p.category))];

        // Create and append filter buttons
        if (filtersContainer) {
            categories.forEach(category => {
                const button = document.createElement('button');
                button.className = 'filter-btn px-4 py-2 text-sm md:text-base font-medium rounded-full border border-gray-300 hover:bg-gray-100 transition duration-300';
                button.textContent = category;
                button.dataset.category = category;
                if (category === 'All') {
                    button.classList.add('active');
                }
                filtersContainer.appendChild(button);
            });

            // Add event listeners to filter buttons
            filtersContainer.addEventListener('click', (e) => {
                if (e.target.tagName === 'BUTTON') {
                    // Update active button style
                    filtersContainer.querySelector('.active').classList.remove('active');
                    e.target.classList.add('active');

                    const selectedCategory = e.target.dataset.category;
                    const filteredProducts = selectedCategory === 'All'
                        ? products
                        : products.filter(p => p.category === selectedCategory);
                    
                    renderProductGrid(filteredProducts);
                }
            });
        }
        
        // Initial render of all products
        renderProductGrid(products);
    }

    // --- Product Detail Page Logic (`product.html`) with size selection ---
    if (path === 'product.html') {
        const params = new URLSearchParams(window.location.search);
        const productId = parseInt(params.get('id'));
        const product = products.find(p => p.id === productId);
        
        const container = document.getElementById('product-detail-container');
        if (product && container) {
            // Create size options HTML
            const sizeOptions = product.sizes ? 
                `<div class="mb-6">
                    <h3 class="text-sm font-medium text-gray-900 mb-2">Size</h3>
                    <div class="flex flex-wrap gap-2">
                        ${product.sizes.map(size => `
                            <button type="button" class="size-btn w-12 h-12 flex items-center justify-center border rounded-md hover:border-indigo-500 transition ${size === (product.sizes.includes('M') ? 'M' : product.sizes[0]) ? 'border-indigo-500 bg-indigo-50' : 'border-gray-300'}" data-size="${size}">
                                ${size}
                            </button>
                        `).join('')}
                    </div>
                </div>` : '';
            
            container.innerHTML = `
                <div class="lg:w-1/2">
                    <img src="${product.image}" alt="${product.name}" class="w-full rounded-lg shadow-lg">
                </div>
                <div class="lg:w-1/2">
                    <h1 class="text-4xl font-bold mb-2">${product.name}</h1>
                    <p class="text-gray-500 text-sm mb-4">Category: ${product.category}</p>
                    <p class="text-gray-600 mb-6">${product.description}</p>
                    ${sizeOptions}
                    <p class="text-3xl font-bold text-indigo-600 mb-8">₹${product.price.toLocaleString('en-IN')}</p>
                    <button class="add-to-cart-btn w-full md:w-auto bg-indigo-600 text-white py-3 px-8 rounded-lg font-semibold hover:bg-indigo-700 transition duration-300" data-product-id="${product.id}">Add to Cart</button>
                </div>
            `;
            
            // Handle size selection
            container.querySelectorAll('.size-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    container.querySelectorAll('.size-btn').forEach(b => 
                        b.classList.remove('border-indigo-500', 'bg-indigo-50'));
                    btn.classList.add('border-indigo-500', 'bg-indigo-50');
                });
            });
            
            container.querySelector('.add-to-cart-btn').addEventListener('click', e => {
                const selectedSize = container.querySelector('.size-btn.border-indigo-500')?.dataset.size || 'One Size';
                addToCart(parseInt(e.target.dataset.productId), selectedSize);
                e.target.innerText = 'Added!';
                e.target.classList.replace('bg-indigo-600', 'bg-green-500');
            });
        } else if (container) {
            container.innerHTML = `<p class="text-center w-full text-red-500">Product not found.</p>`;
        }
    }

    // --- Cart & Checkout Page Logic (updated to show sizes) ---
    function renderCartPages() {
        const isCartPage = path === 'cart.html';
        const isCheckoutPage = path === 'checkout.html';
        
        const cartItemsList = document.getElementById('cart-items-list');
        const cartSummary = document.getElementById('cart-summary');
        const checkoutSummaryItems = document.getElementById('summary-items');
        const checkoutSummaryTotal = document.getElementById('summary-total');

        if (cart.length === 0) {
            if(isCartPage && cartItemsList) cartItemsList.innerHTML = `<p class="text-center text-gray-500">Your cart is empty. <a href="shop.html" class="text-indigo-600 hover:underline">Start shopping!</a></p>`;
            if(isCartPage && cartSummary) cartSummary.innerHTML = '';
            if(isCheckoutPage && checkoutSummaryItems) checkoutSummaryItems.innerHTML = `<p class="text-gray-500">No items in cart.</p>`;
            if(isCheckoutPage) {
                const form = document.getElementById('checkout-form');
                if (form) form.querySelector('button[type="submit"]').disabled = true;
            }
            return;
        }

        let subtotal = 0;
        let cartContent = '';
        let checkoutContent = '';

        cart.forEach(cartItem => {
            const product = products.find(p => p.id === cartItem.id);
            if (!product) return;
            const itemTotal = product.price * cartItem.quantity;
            subtotal += itemTotal;
            
            if (isCartPage) {
                cartContent += `
                    <div class="flex items-center justify-between py-4 border-b flex-wrap">
                        <div class="flex items-center gap-4 mb-2 sm:mb-0">
                            <img src="${product.image}" alt="${product.name}" class="w-20 h-20 object-cover rounded-md">
                            <div>
                                <h3 class="font-semibold">${product.name}</h3>
                                <p class="text-gray-600">₹${product.price.toLocaleString('en-IN')}</p>
                                ${cartItem.size ? `<p class="text-sm text-gray-500">Size: ${cartItem.size}</p>` : ''}
                            </div>
                        </div>
                        <div class="flex items-center gap-2 md:gap-4 ml-auto">
                            <div class="flex items-center border rounded-md">
                                <button class="quantity-change px-3 py-1" data-product-id="${product.id}" data-size="${cartItem.size}" data-change="-1">-</button>
                                <span class="px-3 py-1">${cartItem.quantity}</span>
                                <button class="quantity-change px-3 py-1" data-product-id="${product.id}" data-size="${cartItem.size}" data-change="1">+</button>
                            </div>
                            <p class="font-bold w-24 text-right">₹${itemTotal.toLocaleString('en-IN')}</p>
                            <button class="remove-item text-red-500 hover:text-red-700" data-product-id="${product.id}" data-size="${cartItem.size}">Remove</button>
                        </div>
                    </div>
                `;
            }

            if (isCheckoutPage) {
                checkoutContent += `
                    <div class="flex justify-between">
                        <span>${product.name} ${cartItem.size ? `(Size: ${cartItem.size})` : ''} (x${cartItem.quantity})</span>
                        <span>₹${itemTotal.toLocaleString('en-IN')}</span>
                    </div>
                `;
            }
        });

        const tax = subtotal * 0.18; // 18% GST
        const total = subtotal + tax;

        if (isCartPage && cartItemsList && cartSummary) {
            cartItemsList.innerHTML = cartContent;
            cartSummary.innerHTML = `
                <div class="flex justify-between text-lg"><span>Subtotal</span><span>₹${subtotal.toLocaleString('en-IN')}</span></div>
                <div class="flex justify-between text-lg mt-2"><span>GST (18%)</span><span>₹${tax.toLocaleString('en-IN')}</span></div>
                <div class="flex justify-between text-2xl font-bold mt-4"><span>Total</span><span>₹${total.toLocaleString('en-IN')}</span></div>
                <a href="checkout.html" class="block w-full text-center mt-8 bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700 transition">Proceed to Checkout</a>
            `;
            
            cartItemsList.querySelectorAll('.quantity-change, .remove-item').forEach(button => {
                button.addEventListener('click', e => {
                    const productId = parseInt(e.target.dataset.productId);
                    const size = e.target.dataset.size || 'One Size';
                    
                    if (e.target.classList.contains('remove-item')) {
                        cart = cart.filter(i => i.id !== productId || i.size !== size);
                    } else {
                        const change = parseInt(e.target.dataset.change);
                        const item = cart.find(i => i.id === productId && i.size === size);
                        if (item) {
                            item.quantity += change;
                            if (item.quantity <= 0) cart = cart.filter(i => i.id !== productId || i.size !== size);
                        }
                    }
                    saveCart();
                    renderCartPages(); // Re-render the cart
                });
            });
        }
        
        if (isCheckoutPage && checkoutSummaryItems && checkoutSummaryTotal) {
            checkoutSummaryItems.innerHTML = checkoutContent;
            checkoutSummaryTotal.innerHTML = `<div class="flex justify-between font-bold text-xl mt-4 pt-4 border-t"><span>Total (incl. GST)</span><span>₹${total.toLocaleString('en-IN')}</span></div>`;
        }
    }

    if(path === 'cart.html' || path === 'checkout.html') {
        renderCartPages();
    }
    
    // --- Shared Modal Logic ---
    const modal = document.getElementById('order-modal');
    function showModal(config) {
        if (!modal) return;
        const modalTitle = document.getElementById('modal-title');
        const modalMessage = document.getElementById('modal-message');
        const modalIconContainer = document.getElementById('modal-icon-container');
        const modalButtons = document.getElementById('modal-buttons');

        if (!modalTitle || !modalMessage || !modalIconContainer || !modalButtons) return;

        modalTitle.textContent = config.title;
        modalMessage.innerHTML = config.message;
        
        modalIconContainer.innerHTML = config.icon.svg;
        modalIconContainer.className = `mx-auto flex items-center justify-center h-12 w-12 rounded-full ${config.icon.bgColor}`;

        modalButtons.innerHTML = ''; 
        config.buttons.forEach(btnConfig => {
            const button = document.createElement('button');
            button.textContent = btnConfig.text;
            button.className = btnConfig.classes;
            button.onclick = () => {
                modal.classList.add('hidden');
                if(btnConfig.onClick) btnConfig.onClick();
            };
            modalButtons.appendChild(button);
        });

        modal.classList.remove('hidden');
    }

    // --- Checkout Page Logic (Validation and Order Creation) ---
    if (path === 'checkout.html') {
        const form = document.getElementById('checkout-form');
        const cardNumberInput = document.getElementById('card-number');
        const expiryInput = document.getElementById('expiry');
        const cvcInput = document.getElementById('cvc');

        form?.addEventListener('submit', (e) => {
            e.preventDefault(); 
            
            // Prevent submission if cart is empty
            if (cart.length === 0) {
                showModal({
                    title: 'Empty Cart',
                    message: 'You cannot place an order because your shopping cart is empty.',
                    icon: {
                        svg: `<svg class="h-6 w-6 text-yellow-600" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" /></svg>`,
                        bgColor: 'bg-yellow-100'
                    },
                    buttons: [{
                        text: 'Go Shopping',
                        classes: 'px-4 py-2 bg-indigo-600 text-white text-base font-medium rounded-md w-full shadow-sm hover:bg-indigo-700',
                        onClick: () => window.location.href = 'shop.html'
                    }]
                });
                return;
            }

            const cardNumberError = document.getElementById('card-number-error');
            const expiryError = document.getElementById('expiry-error');
            const cvcError = document.getElementById('cvc-error');

            let isFormValid = true;

            [cardNumberInput, expiryInput, cvcInput].forEach(input => input.classList.remove('invalid-card-field'));
            [cardNumberError, expiryError, cvcError].forEach(span => span.textContent = '');

            if (cardNumberInput.value.replace(/\s/g, '').length !== 16) {
                isFormValid = false;
                cardNumberInput.classList.add('invalid-card-field');
                cardNumberError.textContent = 'Card number must be 16 digits.';
            }

            const match = expiryInput.value.match(/^(\d{1,2})\s*\/?\s*(\d{2})$/);
            let isExpiryValid = false;
    
            if (match) {
                const month = parseInt(match[1], 10);
                const year = parseInt(match[2], 10);
    
                if (!isNaN(month) && !isNaN(year) && month >= 1 && month <= 12) {
                    const now = new Date();
                    const currentYear = now.getFullYear() % 100;
                    const currentMonth = now.getMonth() + 1;
    
                    if (year > currentYear || (year === currentYear && month >= currentMonth)) {
                        isExpiryValid = true;
                    }
                }
            }
    
            if (!isExpiryValid) {
                isFormValid = false;
                expiryInput.classList.add('invalid-card-field');
                expiryError.textContent = 'Card is expired or date is invalid.';
            }

            if (cvcInput.value.length !== 3) {
                isFormValid = false;
                cvcInput.classList.add('invalid-card-field');
                cvcError.textContent = 'CVC must be 3 digits.';
            }
            
            if (!isFormValid) {
                showModal({
                    title: 'Payment Error',
                    message: 'Please correct the highlighted fields and try again.',
                    icon: {
                        svg: `<svg class="h-6 w-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" /></svg>`,
                        bgColor: 'bg-red-100'
                    },
                    buttons: [{
                        text: 'OK',
                        classes: 'px-4 py-2 bg-indigo-600 text-white text-base font-medium rounded-md w-full shadow-sm hover:bg-indigo-700'
                    }]
                });
            } else {
                // If form is valid, proceed with creating the order
                const orderId = `SZN-${Date.now().toString().slice(-6)}`;
                const now = new Date();
                const deliveryDate = new Date(now);
                deliveryDate.setDate(now.getDate()+ 5);

                const newOrder = {
                    id: orderId,
                    date: now.toISOString(),
                    estimatedDelivery: deliveryDate.toISOString(),
                    status: "Processing",
                    items: cart.map(item => ({...products.find(p => p.id === item.id), quantity: item.quantity })),
                    total: cart.reduce((sum, item) => sum + products.find(p => p.id === item.id).price * item.quantity, 0) * 1.18
                };
                
                orders.unshift(newOrder);
                saveOrders();
                cart = [];
                saveCart();
                
                showModal({
                    title: 'Order Placed Successfully!',
                    message: `Your order has been placed. <br>Your Order ID is: <strong class="text-gray-800">${orderId}</strong>. <br>You can view its status in 'My Orders'.`,
                    icon: {
                        svg: `<svg class="h-6 w-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>`,
                        bgColor: 'bg-green-100'
                    },
                    buttons: [{
                        text: 'Go to My Orders',
                        classes: 'px-4 py-2 bg-indigo-600 text-white text-base font-medium rounded-md w-full shadow-sm hover:bg-indigo-700',
                        onClick: () => window.location.href = 'my-orders.html'
                    }]
                });
            }
        });
    }

    // --- My Orders Page Logic ---
    if (path === 'my-orders.html') {
        const ordersContainer = document.getElementById('orders-container');
        
        function renderOrders() {
            if (!ordersContainer) return;
            const sortedOrders = orders.slice().sort((a, b) => new Date(b.date) - new Date(a.date));

            if (sortedOrders.length === 0) {
                ordersContainer.innerHTML = `<div class="text-center py-12 bg-white rounded-lg shadow-md"><p class="text-gray-500">You haven't placed any orders yet.</p><a href="shop.html" class="mt-4 inline-block bg-indigo-600 text-white py-2 px-4 rounded-lg font-semibold hover:bg-indigo-700">Start Shopping</a></div>`;
                return;
            }

            ordersContainer.innerHTML = sortedOrders.map(order => {
                const statusColor = {
                    Processing: 'bg-yellow-100 text-yellow-800', Shipped: 'bg-blue-100 text-blue-800',
                    Delivered: 'bg-green-100 text-green-800', Cancelled: 'bg-red-100 text-red-800',
                };
                const canCancel = order.status === 'Processing';
                return `
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="p-4 bg-gray-50 border-b flex justify-between items-center flex-wrap gap-2">
                        <div><p class="font-bold text-gray-800">Order ID: ${order.id}</p><p class="text-sm text-gray-500">Placed on: ${new Date(order.date).toLocaleDateString('en-IN')}</p></div>
                        <div><p class="text-sm text-gray-500">Total</p><p class="font-bold text-gray-800">₹${order.total.toLocaleString('en-IN')}</p></div>
                    </div>
                    <div class="p-4">
                        <div class="mb-4"><p class="font-semibold text-lg mb-2 ${order.status === 'Cancelled' ? 'text-red-600' : 'text-green-600'}">${order.status === 'Cancelled' ? 'Cancelled' : `Estimated Delivery: ${new Date(order.estimatedDelivery).toLocaleDateString('en-IN')}`}</p><div class="flex items-center gap-2"><span class="text-sm font-medium px-2.5 py-0.5 rounded ${statusColor[order.status] || 'bg-gray-100 text-gray-800'}">${order.status}</span></div></div>
                        <div class="space-y-3 mb-4 max-h-40 overflow-y-auto">${order.items.map(item => `<div class="flex items-center gap-4"><img src="${item.image}" alt="${item.name}" class="w-16 h-16 object-cover rounded-md"><div><p class="font-semibold text-gray-800">${item.name}</p><p class="text-sm text-gray-500">Quantity: ${item.quantity}</p></div></div>`).join('')}</div>
                        <div class="flex gap-2 justify-end">
                            <button class="view-details-btn text-indigo-600 font-semibold py-2 px-4 rounded-md hover:bg-indigo-50" data-order-id="${order.id}">View Details</button>
                            <button class="cancel-order-btn py-2 px-4 rounded-md font-semibold ${canCancel ? 'bg-red-600 text-white hover:bg-red-700' : 'bg-gray-200 text-gray-500 cursor-not-allowed'}" ${!canCancel ? 'disabled' : ''} data-order-id="${order.id}">Cancel Order</button>
                        </div>
                    </div>
                </div>`;
            }).join('');
            attachOrderButtonListeners();
        }

        function attachOrderButtonListeners() {
            ordersContainer.querySelectorAll('.cancel-order-btn').forEach(button => {
                button.addEventListener('click', e => {
                    const orderId = e.target.dataset.orderId;
                    showModal({
                        title: 'Confirm Cancellation', message: `Are you sure you want to cancel order <strong>${orderId}</strong>? This action cannot be undone.`,
                        icon: { svg: `<svg class="h-6 w-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" /></svg>`, bgColor: 'bg-red-100'},
                        buttons: [
                            { text: 'Do Not Cancel', classes: 'px-4 py-2 bg-gray-200 text-gray-800 text-base font-medium rounded-md w-full shadow-sm hover:bg-gray-300' },
                            { text: 'Yes, Cancel Order', classes: 'px-4 py-2 bg-red-600 text-white text-base font-medium rounded-md w-full shadow-sm hover:bg-red-700',
                                onClick: () => {
                                    const orderIndex = orders.findIndex(o => o.id === orderId);
                                    if (orderIndex > -1) { orders[orderIndex].status = 'Cancelled'; saveOrders(); renderOrders(); }
                                }
                            }
                        ]
                    });
                });
            });

            ordersContainer.querySelectorAll('.view-details-btn').forEach(button => {
                button.addEventListener('click', e => {
                    const orderId = e.target.dataset.orderId;
                    const order = orders.find(o => o.id === orderId);
                    const statuses = ["Processing", "Shipped", "Delivered"];
                    const currentStatusIndex = order ? statuses.indexOf(order.status) : -1;
                    const trackingHTML = order.status === 'Cancelled' ? `<div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-md" role="alert"><p class="font-bold">Order Cancelled</p><p>This order has been cancelled.</p></div>` :
                        `<div class="space-y-8 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-slate-300 before:to-transparent">${statuses.map((status, index) => `<div class="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group ${index <= currentStatusIndex ? 'completed' : ''}"><div class="flex items-center justify-center w-10 h-10 rounded-full border-2 border-slate-300 bg-slate-50 text-slate-500 shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 timeline-dot"><svg class="fill-current" xmlns="http://www.w3.org/2000/svg" width="12" height="10"><path fill-rule="nonzero" d="M10.422 1.257 4.655 7.025 2.553 4.923A.916.916 0 0 0 1.257 6.22l2.75 2.75a.916.916 0 0 0 1.296 0l6.415-6.416a.916.916 0 0 0-1.296-1.296Z"/></svg></div><div class="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] bg-white p-4 rounded border border-slate-200 shadow"><div class="font-bold text-slate-900 timeline-text">${status}</div></div></div>`).join('')}</div>`;

                    showModal({
                        title: `Tracking Details for ${orderId}`,
                        message: `<div class="text-left"><p class="mb-1"><strong class="font-medium">Order Date:</strong> ${new Date(order.date).toLocaleDateString('en-IN')}</p><p class="mb-4"><strong class="font-medium">Estimated Delivery:</strong> ${new Date(order.estimatedDelivery).toLocaleDateString('en-IN')}</p></div>${trackingHTML}`,
                        icon: { svg: `<svg class="h-6 w-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M8.25 18.75a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h6m-9 0H3.375a1.125 1.125 0 01-1.125-1.125V14.25m17.25 4.5a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h1.125c.621 0 1.125-.504 1.125-1.125V14.25m-17.25 4.5v-1.875a3.375 3.375 0 003.375-3.375h1.5a1.125 1.125 0 011.125 1.125v-1.5a3.375 3.375 0 00-3.375-3.375H3.375m15.75 9V12.75a3.375 3.375 0 00-3.375-3.375h-1.5a1.125 1.125 0 01-1.125-1.125v-1.5a3.375 3.375 0 003.375-3.375H19.5" /></svg>`, bgColor: 'bg-indigo-100'},
                        buttons: [{ text: 'Close', classes: 'px-4 py-2 bg-gray-200 text-gray-800 text-base font-medium rounded-md w-full shadow-sm hover:bg-gray-300' }]
                    });
                });
            });
        }
        
        // Initial Render
        renderOrders();
    }

});