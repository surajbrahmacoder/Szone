// save as server.js
const express = require('express');
const axios = require('axios');
const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const BOT_TOKEN = 'YOUR_BOT_TOKEN';
const CHAT_ID = 'YOUR_CHAT_ID';

app.post('/send-message', async (req, res) => {
  const { name, email, message } = req.body;

  const text = `New Contact Form Message:\nName: ${name}\nEmail: ${email}\nMessage: ${message}`;

  try {
    await axios.post(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
      chat_id: CHAT_ID,
      text: text,
    });
    res.send('Message sent to Telegram!');
  } catch (error) {
    console.error(error);
    res.status(500).send('Failed to send message');
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
