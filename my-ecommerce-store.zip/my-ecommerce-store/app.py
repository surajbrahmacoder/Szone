from flask import Flask, request, jsonify, send_from_directory, redirect, url_for
from openpyxl import Workbook, load_workbook
import os

app = Flask(__name__)

EXCEL_FILE = "user_data.xlsx"

# Create Excel file if not exists
if not os.path.exists(EXCEL_FILE):
    wb = Workbook()
    ws = wb.active
    ws.append(["Email", "Password"])
    wb.save(EXCEL_FILE)

# Serve signup page
@app.route('/')
@app.route('/signup.html')
def serve_signup():
    return send_from_directory('.', 'signup.html')

# Serve login page
@app.route('/login.html')
def serve_login():
    return send_from_directory('.', 'login.html')

# Serve welcome page
@app.route('/welcome.html')
def serve_welcome():
    return send_from_directory('.', 'welcome.html')

# Serve other static files
@app.route('/<path:filename>')
def serve_static(filename):
    if os.path.exists(filename):
        return send_from_directory('.', filename)
    else:
        return "File not found", 404

@app.route('/signup', methods=['POST'])
def signup():
    data = request.get_json()
    email = data.get("email")
    password = data.get("password")

    # Save to Excel
    wb = load_workbook(EXCEL_FILE)
    ws = wb.active
    ws.append([email, password])
    wb.save(EXCEL_FILE)

    # Return redirect response instead of JSON
    return jsonify({
        "redirect": "/welcome.html",
        "message": "Signup successful"
    }), 200

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    email = data.get("email")
    password = data.get("password")

    wb = load_workbook(EXCEL_FILE)
    ws = wb.active

    # Check each row for matching email and password
    for row in ws.iter_rows(min_row=2, values_only=True):
        stored_email, stored_password = row
        if stored_email == email and stored_password == password:
            # Return redirect response instead of JSON
            return jsonify({
                "redirect": "/welcome.html",
                "message": "Login successful"
            }), 200

    return jsonify({"message": "Incorrect email or password"}), 401

if __name__ == '__main__':
    app.run(debug=True)
